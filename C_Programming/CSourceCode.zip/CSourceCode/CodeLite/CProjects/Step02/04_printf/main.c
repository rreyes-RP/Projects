#include <stdio.h>

int main(int argc, char **argv) {
	printf("hello world\n");
	puts("hello world again\n");
	printf("There are %d bottles standing on the %s.\n", 20, "wall" );
	return 0;
}
