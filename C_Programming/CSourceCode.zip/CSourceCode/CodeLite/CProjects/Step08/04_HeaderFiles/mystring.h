#define BUFSIZE 100
int readln(char[], int);
int searchstring(char[], char[]);